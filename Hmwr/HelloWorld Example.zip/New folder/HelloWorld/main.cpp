/* 
 * File:   main.cpp
 * Author: OSCAR MAYORGA 
 * Created on January 5, 2015, 10:35 AM
 * Porpuse: First Program
 */ 

//System Library 
#include <cstdlib>
#include<iostream>
using namespace std;

//User Library 
 
//Global Constant 
 
//Funtion Prototype

//Execution Begins!
        

int main(int argc, char** argv) {
    //output Hello World 
    cout<<"Hello World"<<endl;
         //Exit Stage Right!
    return 1;
}

