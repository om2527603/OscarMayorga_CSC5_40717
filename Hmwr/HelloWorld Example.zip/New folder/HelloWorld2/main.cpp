/* 
 * File:   main.cpp
 * Author: OSCAR MAYORGA 
 * Created on January 5, 2015, 10:35 AM
 * Porpuse: First Program 
 */ 

//System Library 
#include <cstdlib>
#include<iostream>
using namespace std;

//User Library 
 
//Global Constant 
 
//Funtion Prototype

//Execution Begins!
int main(int argc, char** argv) {
    //output Prompt for Input  
    cout<<"Hello World"<<endl;
      //Input the Integer 
    int x; 
    cin>>x;
    //output the input 
    return 1;
}


